export class Constants {
    static getConversion() {
        return {
            'trainingType': {
                'Online': {
                    'convertHoursToMinutes': 60,
                    'minutes': 'Minutes'
                },
                'Classroom': {
                    'convertDaysToHours': 8,
                    'hours': 'Hours'
                }
            }
        };
    }
}
