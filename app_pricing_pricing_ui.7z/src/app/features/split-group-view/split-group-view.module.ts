import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { SplitGroupViewRoutingModule } from './split-group-view-routing.module';
import { SplitGroupViewComponent } from './split-group-view.component';
import { TableModule } from 'primeng/table';
import { BreadcrumbModule} from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { PaginatorModule } from 'primeng/paginator';
import {DataScrollerModule} from 'primeng/datascroller';
import {CheckboxModule} from 'primeng/checkbox';



@NgModule({
    imports: [
        CommonModule,
        HttpClientModule,
        SplitGroupViewRoutingModule,
        TableModule,
        BreadcrumbModule,
        OverlayPanelModule,
        PaginatorModule,
        DataScrollerModule,
        CheckboxModule
    ],
    declarations: [SplitGroupViewComponent]
})
export class SplitGroupViewModule { }
