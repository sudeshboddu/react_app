import { TestBed, inject, async } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { SplitGroupViewService } from './split-group-view-service';

describe('SplitGroupViewService.Service', () => {

    const response = [
        {
            'status': 'Approved',
            'effectiveTimestamp': '2018-10-02T15:01:25.8399232Z',
            'expirationTimestamp': '2018-10-02T15:01:25.8399232Z',
            'splitRateGroupName': 'BNSF Split Group 1'
        }
    ];

    let splitGroupViewService: SplitGroupViewService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule, HttpClientModule],
            providers: [SplitGroupViewService]
        });

        splitGroupViewService = TestBed.get(SplitGroupViewService);
        httpMock = TestBed.get(HttpTestingController);
    });


    it('should load the service class', () => {
        expect(httpMock).toBeTruthy();
    });

    it('should be created', inject([SplitGroupViewService],
        (service: SplitGroupViewService) => {
            expect(service).toBeTruthy();
        }));

    it('should return a json object', async(() => {
        splitGroupViewService.getSplitViewGroupData().subscribe(splitgroup => {
            expect(splitgroup).toContain(response);
            const request = httpMock.expectOne('./assets/mocks/splitgroup.json');
            request.flush([response]);
        });
    }));

    it('should run a get command', async(() => {

        splitGroupViewService.getSplitViewGroupData().subscribe(splitgroup => {
            expect(splitgroup).toContain(response);
            const request = httpMock.expectOne('assets/mocks/splitgroup.json');
            expect(request.request.method).toEqual('GET');

        });
    }));

});
