import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpModule } from '@angular/http';

@Injectable({
    providedIn: 'root'
})
export class SplitGroupViewService {
    splitGroupViewUrl = './assets/mock/splitgroup.json';

    constructor(public http: HttpClient) {
    }

    getSplitViewGroupData(): Observable<any> {
        return this.http.get<any>(this.splitGroupViewUrl);
    }
}
