import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SplitGroupViewComponent } from './split-group-view.component';

const routes: Routes = [
  {
    path: '',
    component : SplitGroupViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class SplitGroupViewRoutingModule { }
