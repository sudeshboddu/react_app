import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { SplitGroupViewComponent } from './split-group-view.component';
import { TableModule } from 'primeng/table';
import { BreadcrumbModule } from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { PaginatorModule } from 'primeng/paginator';
import { DataScrollerModule } from 'primeng/datascroller';
import { CheckboxModule } from 'primeng/checkbox';
import { SplitGroupViewService } from './services/split-group-view-service';
import { HttpClientModule } from '@angular/common/http';


describe('SplitGroupViewComponent', () => {
  let component: SplitGroupViewComponent;
  let fixture: ComponentFixture<SplitGroupViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SplitGroupViewComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [CheckboxModule, DataScrollerModule, TableModule, BreadcrumbModule, OverlayPanelModule, PaginatorModule,
        HttpClientModule],
      providers: [SplitGroupViewService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplitGroupViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it(`should have array of values '`, async(() => {
    fixture = TestBed.createComponent(SplitGroupViewComponent);
    const app = fixture.debugElement.componentInstance;
    app.ngOnInit();
    expect(app.cols).toEqual([]);
  }));

  // it('should be created', inject([SplitGroupViewComponent],
  //   () => {
  //     expect(true).toBeTruthy();
  // }));

  // it('should be truthy', () => {
  //   expect(true).toBe(true);
  // });

});
