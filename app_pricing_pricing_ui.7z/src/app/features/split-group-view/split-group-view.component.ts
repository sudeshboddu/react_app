import { Component, OnInit } from '@angular/core';
import { SplitGroupViewService } from './services/split-group-view-service';

@Component({
  selector: 'app-split-group-view',
  templateUrl: './split-group-view.component.html',
  styleUrls: ['./split-group-view.component.scss']
})
export class SplitGroupViewComponent implements OnInit {
  items: any;
  splitgroup: any[];
  cols: any[];
  constructor(private readonly _splitGroupViewService: SplitGroupViewService) { }

  ngOnInit() {

    this.items = [
      { label: 'Pricing', routerLink: ['/dashboard'] },
      { label: 'Search Agreements', routerLinkActiveOptions: ['/searchagreements'] },
      { label: 'Agreement Details', routerLinkActiveOptions: ['/agreementdetails'] },
      { label: 'Split Groups', routerLinkActiveOptions: ['/splitgroupview'] },

    ];
    this._splitGroupViewService.getSplitViewGroupData().subscribe(splitgroup => {
      this.splitgroup = splitgroup;
      console.log(this.splitgroup);
    });

    this.cols = [
      { field: 'splitRateGroupName', header: 'Group Name' },
      { field: 'effectiveTimestamp', header: 'Effective Date', type: 'date' },
      { field: 'expirationTimestamp', header: 'Expiration Date', type: 'date' },
      { field: 'status', header: 'Status' }
    ];


  }

}
