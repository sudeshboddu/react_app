export class AppConfig {
    static getConfig() {
        return {
            'api': {
                'segments': {
                    'getsegmentnames': 'api/safetytraining/segments/fetchsegmentnames',
                    'searchsegments': 'api/safetytraining/segments/segmentsLivesearch',
                    'createsegment': 'api/safetytraining/segments/Create',
                    'segmentassociationcheck': 'api/safetytraining/segments/checkModuleAssosiation',
                    'segmentsinactivate': 'api/safetytraining/segments/multipledeactivate',
                    'fetchsegment': 'api/safetytraining/segments/getQAEdit',
                    'updatesegment': 'api/safetytraining/segments/Update',
                    'segmentquestionanswers': 'api/safetytraining/parameters'
                },
                'categories': {
                    'checkduplcatecategories': 'api/safetytraining/categories/checkduplicate',
                    'searchcategories': 'api/safetytraining/categories/categoriesLiveSearch',
                    'addCategories': 'api/safetytraining/categories/addCategory'
                }
            }
        };
    }
}
