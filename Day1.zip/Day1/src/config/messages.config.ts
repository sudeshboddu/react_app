
export class Messages {
    static getMessage() {
        return {
            'success': {
                'segments': {
                    'single': 'You have successfully inactivated'
                }
            },
            'confirmationMessages': {
                'associations': {
                    'noSegmentAssociated': {
                        'single': 'Do you want to inactivate this training segment?',
                        'multiple': 'Do you want to inactivate these training segments?'
                    },
                    'allSegmentsAssociated': {
                        'single': `Selected segment is attached to one or more courses and it is actively assigned to a
                                    user. Do you still want to inactivate the segment?`,
                        'multiple': `Selected segments are attached to one or more courses and it is actively assigned to a
                                     user. Do you still want to inactivate these segments?`
                    },
                    'someSegmentsAssociated': `Some of the selected segments are attached to one or more courses and
                     it is actively assigned to a user. Do you still want to inactivate these segments?`
                }
            },
            'cancelDiscardMsgs': {
                'cancelMessage': 'Are you sure you want to cancel create segment?',
                'discardMessage': 'You are about to lose all changes made. Do you wish to continue?',
                'cancelHeader': 'Confirm Cancel',
                'discardHeader': 'Discard Changes',
                'editCancelMessage': 'Are you sure you want to cancel edit segment?'
            },
            'resetMsgs': {
                'resetMessage': 'Are you sure you want to reset the course settings?',
                'resetHeader': 'Reset Changes?',
                'discardSettingsMessage': 'You are about to lose all changes made, do you wish to continue?',
                'discardSettingsHeader': 'Discard Changes?'
            }
        };
    }

}
