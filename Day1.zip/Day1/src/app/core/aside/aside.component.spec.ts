import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AsideComponent } from './aside.component';
import { AsideNavComponent } from './nav/aside-nav.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { ReturnStatement } from '@angular/compiler';

describe('AsideComponent', () => {
  let component: AsideComponent;
  let fixture: ComponentFixture<AsideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsideComponent
                      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
  it('should toggle sidebar', () => {
    component.onToggleSidebarLeft();
    component.isChanging = false;
    component.onToggleSidebarLeft();
    component.isLocked = false;
    component.isOpen = false;
    expect(component.showAppDrawer === false);
  });
  it('should lock sidebar', () => {
    component.onLockSidebarLeft();
    expect(component.asideToggleLock).toBeDefined();
  });
  it('should return sidebar locked css', () => {
    component.getSidebarLockIcon();
    expect(ReturnStatement);
  });
  it('should toggle app drawer', () => {
    component.onToggleAppDrawer();
    expect(component.showAppDrawer).toBeTruthy();
  });
});
