import { TestBed, inject } from '@angular/core/testing';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { RouteGuardService } from './route-guard.service';
import { CanComponentDeactivate } from './canComponentDeactivate-interface';

describe('RouteGuardService', () => {
  class MockCanComponentDeactivate {
    canDeactivate: (component, route, state) => Observable<boolean> | Promise<boolean> | boolean;
  }
  const component = new MockCanComponentDeactivate;
  const route = jasmine.createSpyObj<ActivatedRouteSnapshot>('ActivatedRouteSnapshot', ['toString']);
  const state = jasmine.createSpyObj<RouterStateSnapshot>('RouterStateSnapshot', ['toString']);

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RouteGuardService,
        { provide: ActivatedRouteSnapshot, useValue: route },
        { provide: RouterStateSnapshot, useValue: state }
      ]
    });
  });

  it('should be created', inject([RouteGuardService], (service: RouteGuardService) => {
    expect(service).toBeTruthy();
  }));

  it('should call canDeactivate', inject([RouteGuardService], (service: RouteGuardService) => {
    service.canDeactivate(component, route, state);
    expect(service.canDeactivate(component, route, state)).toBe(true);
  }));

});
