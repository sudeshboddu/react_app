import { Observable } from 'rxjs';

export interface CanComponentDeactivate {
    canDeactivate: (component, route, state) => Observable<boolean> | Promise<boolean> | boolean;
}
