import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Pricing Dashboard',
      pathIcon: `icon-Home`,
      order: 1
    }
  },
  {
    path: 'split-group-view',
    loadChildren: 'app/features/split-group-view/split-group-view.module#SplitGroupViewModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Search Agreements',
      pathIcon: `icon-Search`,
      order: 2
    }
  },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: '/dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
