import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-split-group-view',
  templateUrl: './split-group-view.component.html',
  styleUrls: ['./split-group-view.component.scss']
})
export class SplitGroupViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
