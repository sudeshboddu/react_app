import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SplitGroupViewComponent } from './split-group-view.component';

describe('SplitGroupViewComponent', () => {
  let component: SplitGroupViewComponent;
  let fixture: ComponentFixture<SplitGroupViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplitGroupViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplitGroupViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
