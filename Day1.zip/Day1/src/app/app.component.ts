import {Component, OnInit, AfterViewInit, OnDestroy, ChangeDetectionStrategy, DoCheck} from '@angular/core';
import {isNullOrUndefined} from 'util';
import {Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})

export class AppComponent implements OnInit, OnDestroy {
  isLocked = true;
  /**
   * sidebar states
   * @type {any}
   */
  sidebar: any = {
    left: {
      open: true,
      locked: true,
      changing: false
    },
    right: {
      open: false
    }
  };
  breakPoint = '';
  platform = {};
  logged: any;
  shouldDisplayOverlay = true;
  /**
   * [constructor description]
   * @param {AuthService} private auth
   * @param {Router} private router
   */
  constructor(public router: Router) {
  }

  /**
   * [ngOnInit description]
   *
   */
  ngOnInit() {

  }

  /**
   * [ngOnDestroy description]
   */
  ngOnDestroy() {
    console.log('App Destroy');

  }

  /**
   * resetSidebarState sets sidebar locked and open states back to default (false)
   * @param {[type]} event [description]
   */
  resetSidebarState(event) {
    this.sidebar.left.locked = false;
    this.sidebar.left.open = false;
    this.sidebar.right.open = false;
  }

  /**
   * toggleSidebarLeft is called when a left sidebar toggle event is emitted
   * @param {[type]} event [description]
   */
  toggleSidebarLeft(event) {
    this.sidebar.left.locked = !this.sidebar.left.locked;
    this.sidebar.left.open = !this.sidebar.left.open;
    this.sidebar.right.open = false;
  }

  /**
   * toggleSidebarLeftLock is called when the left sidebar lock toggle event is emitted
   * @param {[type]} event [description]
   */
  toggleSidebarLeftLock(evnet) {
    this.sidebar.left.locked = !this.sidebar.left.locked;
  }

  /**
   * toggleSidebarLeftOpen
   * @param {[type]} state [description]
   */
   toggleSidebarLeftOpen(state?) {
     state = state || !this.sidebar.left.open;
     if (!this.sidebar.left.locked) {
       this.sidebar.left.open = state;
     }
   }
}
