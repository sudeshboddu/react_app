import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';

import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteGuardService } from './shared/jbh-app-services/route-guard.service';
import { NumbersOnlyDirective } from './shared/directives/numbers-only.directive';
//import { SplitGroupViewComponent } from './split-group-view/split-group-view.component';

@NgModule({
  declarations: [
    AppComponent,
    NumbersOnlyDirective
  //  SplitGroupViewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    CoreModule,
    SharedModule,
    BrowserAnimationsModule
  ],
  providers: [
    RouteGuardService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
