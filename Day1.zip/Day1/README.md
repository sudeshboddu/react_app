# Personnel Module 
### TFS Repository Name: `app_pricing_pricing_ui`

---
## Docker Commands 

1. Login to JBHunt artifactory
    - Run `Docker login artifactory-tst.jbhunt.com:8081/artifactory`

2. Local Development with docker.  

    - Open a new console and Run `ng build ---watch --delete-output-path=false` to build and watch your angular files.

    - Open a new console and Run `docker run -p 8080:80 -v ${pwd}/dist:/usr/share/nginx/html nginx:alpine` to point a docker volume to your present working direcotry. 

    - NOTE: When running docker for window you will need to turn on sharing. Also, if you are using "git bash" you will need to add `export MSYS_NO_PATHCONV=1` in your .bash_profile file (It should be in your user directory, but you might have to create it).  

3. Docker Build image 
    - Run `docker build --tag artifactory-tst.jbhunt.com/app_safety_ui:0.0.1 .` to build and tag your image.

4. Test your local image
    - Run `docker run -p 9000:80  artifactory-tst.jbhunt.com/app_safety_ui:0.0.1` to test built image.     

----
## TFS and the @angular/cli Project Generation   
The @angular/cli 1.7.0+ has removed functionality for installing an angular application in an existing directroy. There are many issues filed concerning the `--directory` flag. Hopefully this issue will get addressed soon.  However,the current workaround is as followed.

1.  Create a new git repository in TFS.   
    -   When creating the repo, do not add the ".gitignore" or "readme.md" file. The @angular/cli will create these for you. 
    - The `ng new` command will FAIL if these files exist in the TFS "cloned project". 
2.  RUN `git clone your_repo` in your local workspace. 
    -   This will install the git repository in your present working directory. 
4.  RUN `cd ..` to move into the parent directory. 
    -   This is where the `ng new` command needs to run for installing files in your newly created git project. 
5.  RUN `ng new appName --directory='app_moduleName_ui' --routing --style=scss` to setup your project. 
    -   The `--directory` flag is use to select the target instalation directory. In our case, this would be the git repository we just created.
    -   The `--routing` flag is used to set up the angular router.
    -   The `--style` flag is used to set the css preprocessor you would like to use.  In our case we use "SCSS" for all of our projects.  
  
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.4.

---

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

